<?php
/*
Plugin Name: AD Portfolio
Plugin URI: http://www.ad-theme.com
Description: Portfolio and Carousel WordPress Plugin
Author: Ad-theme.com
Version: 1.4
Author URI: http://www.ad-theme.com
*/

// Basic plugin definitions 
define ('PLG_NAME', 'adportfolio');
define( 'PLG_VERSION', '1.4' );
define( 'adportfolio_URL', WP_PLUGIN_URL . '/' . str_replace( basename(__FILE__), '', plugin_basename(__FILE__) ));
define( 'adportfolio_DIR', WP_PLUGIN_DIR . '/' . str_replace( basename(__FILE__), '', plugin_basename(__FILE__) ));


// Plugin INIT
require_once(adportfolio_DIR.'inc/install.php');