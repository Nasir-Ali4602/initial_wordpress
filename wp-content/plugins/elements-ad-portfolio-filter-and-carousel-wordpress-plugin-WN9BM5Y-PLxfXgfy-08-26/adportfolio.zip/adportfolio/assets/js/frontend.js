/* 
File: assets/js/frontend.js
Description: JS Script for Frontend
Plugin: AD Portfolio
Author: AD-Theme.com
*/

jQuery(function($){

	$(window).load(function(){
		
		$(".item-menu").hover(function() {
			$(".item-menu").addClass("visible")
		});
		$(".item-menu").mouseleave(function() {
			setTimeout(function() {
			$(".item-menu").removeClass("visible")
			}, 500);
		});
		$(".container-item").hover(function() {
			setTimeout(function() {
			$(".container-item").css("z-index","1000")
			}, 500);
		});

	});

});