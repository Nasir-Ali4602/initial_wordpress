/* 
File: assets/js/backend.js
Description: JS Script for Backend
Plugin: AD Portfolio
Author: Ad-theme.com
*/

jQuery(document).ready(function($){
// Custom popup box
	 $("#adportfolio-generator-button").click(function(){
	  $("#adportfolio-generator-wrap, #adportfolio-generator-overlay").show();
	 });
	 
	 $("#adportfolio-generator-close").click(function(){
	  $("#adportfolio-generator-wrap, #adportfolio-generator-overlay").hide();
	 });

	 $("#adportfolio-type").live('click', function(event) {
		 var type = $('#adportfolio-type:checked').val();
		 if(type == 'carousel') {
        	$(".option-carousel").css("display", "block");
			$(".option-portfolio").css("display", "none");
		 }
	 });
	 $("#adportfolio-type").live('click', function(event) {
		 var type = $('#adportfolio-type:checked').val();
	 	 if(type == 'portfolio') {
        	$(".option-carousel").css("display", "none");
			$(".option-portfolio").css("display", "block")
		 }
	 });
	 	 
	 // Insert shortcode
	 $('#adportfolio-generator-insert').live('click', function(event) {
		var type = $('#adportfolio-type:checked').val();
		var style = $('#adportfolio-style').val();
		var category = $('#adportfolio-category').val();
		var number = $('#adportfolio-number').val();
		var autoplay = $('#adportfolio-autoplay').val();
		var postvisible = $('#adportfolio-postvisible').val();
		var navigation_active = $('#adportfolio-carousel-navigation-active').val();
		var dnavigation = $('#adportfolio-carousel-navigation-display').val();
		var pnavigation = $('#adportfolio-carousel-navigation-position').val();
		var custom_size = $('#adportfolio-portfolio-custom-size').val();
		var link_position = $('#adportfolio-portfolio-custom-link-position').val();
		var link_format = $('#adportfolio-portfolio-custom-link-format').val();
		var link_post_url = $('#adportfolio-portfolio-custom-link-post-url').val();
		var link_target = $('#adportfolio-portfolio-custom-link-target').val();
		var title = $('#adportfolio-portfolio-custom-title').val();
		var date = $('#adportfolio-portfolio-custom-date').val();
		var text = $('#adportfolio-portfolio-custom-text').val();
		var excerpt = $('#adportfolio-portfolio-custom-excerpt').val();

		if(type == 'carousel') {
			var shortcode = '[ad'+ type + '_' + style + ' category="' + category + '" number="' + number + '" visible="' + postvisible + '" autoplay="' + autoplay + '" navigation_active="' + navigation_active + '" dnavigation="' + dnavigation + '" pnavigation="' + pnavigation + '"]';
		}
		if(type == 'portfolio') {
			if(style == 'p1style1') { style = 'style1-preset1'; }
			if(style == 'p2style1') { style = 'style1-preset2'; }
			if(style == 'p3style1') { style = 'style1-preset3'; }
			if(style == 'p1style2') { style = 'style2-preset1'; }
			if(style == 'p2style2') { style = 'style2-preset2'; }
			if(style == 'p3style2') { style = 'style2-preset3'; }
			if(style == 'p1style3') { style = 'style3-preset1'; }
			if(style == 'p2style3') { style = 'style3-preset2'; }
			if(style == 'p3style3') { style = 'style3-preset3'; }
			if(style == 'p4style3') { style = 'style3-preset4'; }
			if(style == 'p1style4') { style = 'style4-preset1'; }
			if(style == 'p2style4') { style = 'style4-preset2'; }
			if(style == 'p3style4') { style = 'style4-preset3'; }
			if(style == 'p1style5') { style = 'style5-preset1'; }
			if(style == 'p2style5') { style = 'style5-preset2'; }
			if(style == 'p3style5') { style = 'style5-preset3'; }			
			if(style == 'p4style5') { style = 'style5-preset4'; }
			if(style == 'p5style5') { style = 'style5-preset5'; }
			if(style == 'p6style5') { style = 'style5-preset6'; }
			if(style == 'p7style5') { style = 'style5-preset7'; }
			if(style == 'p8style5') { style = 'style5-preset8'; }
			if(style == 'p9style5') { style = 'style5-preset9'; }						
			if(style == 'p10style5') { style = 'style5-preset10'; }
			if(style ==	'style5-preset1' || style == 'style5-preset2' || style == 'style5-preset3' || style == 'style5-preset4' || style == 'style5-preset5' || style == 'style5-preset6' || style == 'style5-preset7' || style == 'style5-preset8' || style == 'style5-preset9' || style == 'style5-preset10') {	
				var shortcode = '[adportfolio_style5 style="' + style + '" category="' + category + '" number="' + number + '" custom_size="' + custom_size + '" link_position="' + link_position + '" link_format="' + link_format + '" link_post_url="' + link_post_url + '" link_target="' + link_target + '" title="' + title + '" date="' + date + '" text="' + text + '" excerpt="' + excerpt + '"]';
			} else {
				var shortcode = '[adportfolio style="' + style + '" category="' + category + '" number="' + number + '" custom_size="' + custom_size + '" link_position="' + link_position + '" link_format="' + link_format + '" link_post_url="' + link_post_url + '" link_target="' + link_target + '" title="' + title + '" date="' + date + '" text="' + text + '" excerpt="' + excerpt + '"]';
			}
		}
		window.send_to_editor(shortcode);
		$("#adportfolio-generator-wrap, #adportfolio-generator-overlay").hide();
	});
});