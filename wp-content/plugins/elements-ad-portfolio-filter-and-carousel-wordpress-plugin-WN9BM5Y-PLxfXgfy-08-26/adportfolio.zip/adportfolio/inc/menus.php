<?php
/*
File: inc/menus.php
Description: Plugin Menus
Plugin: AD Portfolio
Author: Ad-theme.com
*/


add_action('admin_menu', 'adportfolio_menus');

function adportfolio_menus() {
	
	// Sub Page button for a specific Post Type
    add_submenu_page( 'edit.php?post_type=adportfolio', __('AD Portfolio', PLG_NAME), __('Settings', PLG_NAME), 'manage_options', 'adportfolio_options', 'adportfolio_options');
	
	// Main Custom button 
	add_menu_page('AD Portfolio', 'AD Portfolio', 'manage_options', 'adportfolio-main-page', 'adportfolio_main_page', plugins_url( PLG_NAME.'/assets/img/main_icon.png' ));
	
}