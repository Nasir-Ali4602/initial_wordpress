<?php
/*
File: inc/pages.php
Description: Plugin admin pages
Plugin: AD Portfolio
Author: Ad-theme.com
*/


function adportfolio_main_page() {
	
	
	if (!current_user_can('manage_options'))  {

		wp_die( __('You do not have sufficient permissions to access this page.', 'adportfolio') );

	}
	
	echo '<h2 class="adsidebarpanel-title">AD Portfolio - Options Page</h2>';
	
?>

<?php
	
	if (!empty($_POST['update'])) {
	
	// Check Posted Options
	if(empty($_POST['adportfolio_custom_css'])) { $adportfolio_custom_css = ''; } else { $adportfolio_custom_css = $_POST['adportfolio_custom_css'];}

	// Update Options
	update_option('adportfolio_custom_css', $adportfolio_custom_css );
	
	
	
	}
	// Check Saved Options
	$adportfolio_custom_css = get_option( 'adportfolio_custom_css', '' );	

	echo '<h4>Custom CSS</h4>';
	// Load option fields
	echo '<form method="POST" action="'.$_SERVER['REQUEST_URI'].'">';
	?>
	<?php
	
	echo '<p><textarea class="large" name="adportfolio_custom_css" id="adportfolio_custom_css">';
	if (!empty( $adportfolio_custom_css )){ echo $adportfolio_custom_css; }
    echo '</textarea></p>';
	echo '<p><input type="hidden" name="update" value="update">
	<input type="submit" value="'.__('Save Changes', PLG_NAME).'" class="button-primary" id="submit" name="submit"></p>';
	echo '</form>';
	
}