<?php
/*
File: inc/shortcodes.carousel.style5.php
Description: Plugin shortcodes
Plugin: AD Portfolio
Author: Ad-theme.com
*/

/****************************************** STYLE 5 - PRESET 1 ****************************************/

function adcarousel_style5_p1 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset1 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset1 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-first">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset1 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p1style5 ( $attr ) {
		ob_start();	
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p1($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;     
	}  
add_shortcode("adcarousel_p1style5", "adcarousel_p1style5");

/****************************************** STYLE 5 - PRESET 2 ****************************************/

function adcarousel_style5_p2 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset2 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset2 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-second">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset2 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p2style5 ( $attr ) {
		ob_start();	
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p2($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;     
	}  
add_shortcode("adcarousel_p2style5", "adcarousel_p2style5");

/****************************************** STYLE 5 - PRESET 3 ****************************************/

function adcarousel_style5_p3 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset3 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset3 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-third">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset3 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p3style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p3($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p3style5", "adcarousel_p3style5");

/****************************************** STYLE 5 - PRESET 4 ****************************************/

function adcarousel_style5_p4 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset4 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset4 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-fourth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset4 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p4style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p4($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;   
	}  
add_shortcode("adcarousel_p4style5", "adcarousel_p4style5");

/****************************************** STYLE 5 - PRESET 5 ****************************************/

function adcarousel_style5_p5 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset5 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset5 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-fifth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset5 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p5style5 ( $attr ) {
		ob_start();	
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p5($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p5style5", "adcarousel_p5style5");

/****************************************** STYLE 5 - PRESET 6 ****************************************/

function adcarousel_style5_p6 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset6 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset6 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-sixth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset6 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p6style5 ( $attr ) {
		ob_start();	
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p6($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p6style5", "adcarousel_p6style5");

/****************************************** STYLE 5 - PRESET 7 ****************************************/

function adcarousel_style5_p7 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset7 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset7 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-seventh">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset7 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p7style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p7($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p7style5", "adcarousel_p7style5");

/****************************************** STYLE 5 - PRESET 8 ****************************************/

function adcarousel_style5_p8 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset8 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset8 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-eighth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                   
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset8 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p8style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p8($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p8style5", "adcarousel_p8style5");

/****************************************** STYLE 5 - PRESET 9 ****************************************/

function adcarousel_style5_p9 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset9 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset9 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-ninth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset9 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p9style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p9($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;    
	}  
add_shortcode("adcarousel_p9style5", "adcarousel_p9style5");

/****************************************** STYLE 5 - PRESET 10 ****************************************/

function adcarousel_style5_p10 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style5-preset10 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style5-preset10 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
			<div class="main">
                <div class="view view-tenth">
                    <?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio-style5' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
                    <div class="mask">                
                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        				<h2><?php the_title();?></h2>
        				</a>
                       <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
                        <a href="<?php the_permalink(); ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
                    </div>
                </div>  
			</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style5-preset10 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p10style5 ( $attr ) {
		ob_start();		
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style5_p10($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;      
	}  
add_shortcode("adcarousel_p10style5", "adcarousel_p10style5");