<?php
/*
File: inc/shortcodes.php
Description: Plugin shortcodes
Plugin: AD Portfolio
Author: Ad-theme.com
*/

function adportfolio_button( $page = null, $target = null ) {



  echo '<a href="#" class="button" title="ADD PORTFOLIO/CAROUSEL" id="adportfolio-generator-button"><span class="adportfolio-button-portfolio"></span>Add Portfolio/Carousel</a>';	


 }

add_action( 'media_buttons', 'adportfolio_button', 100 );

function adportfolio_generator() {

	?>

	<div id="adportfolio-generator-overlay" class="adportfolio-overlay-bg" style="display:none"></div>

  <div id="adportfolio-generator-wrap" style="display:none">

   <div id="adportfolio-generator">

       <a href="#" id="adportfolio-generator-close"><span class="adportfolio-close">x</span></a>
       
      <p><?php _e('Select Type', 'adportfolio'); ?></p> 

		<input type="radio" name="adportfolio-type" id="adportfolio-type" value="portfolio">Portfolio
		<input type="radio" name="adportfolio-type" id="adportfolio-type" value="carousel">Carousel
       <br />
       
     <p class="position"><?php _e('Style: ', 'adportfolio'); ?></p>			



     <select id="adportfolio-style" name="adportfolio-style" class="">

     

       <option class="style-preset1" value="p1style1"><?php _e('Style 1 - Preset 1', 'adportfolio'); ?></option>



       <option class="style-preset2" value="p2style1"><?php _e('Style 1 - Preset 2', 'adportfolio'); ?></option>



       <option class="style-preset3" value="p3style1"><?php _e('Style 1 - Preset 3', 'adportfolio'); ?></option>



	   <option class="style2-preset1" value="p1style2"><?php _e('Style 2 - Preset 1', 'adportfolio'); ?></option>



       <option class="style2-preset2" value="p2style2"><?php _e('Style 2 - Preset 2', 'adportfolio'); ?></option>



       <option class="style2-preset3" value="p3style2"><?php _e('Style 2 - Preset 3', 'adportfolio'); ?></option>



       <option class="style3-preset1" value="p1style3"><?php _e('Style 3 - Preset 1', 'adportfolio'); ?></option>



	   <option class="style3-preset2" value="p2style3"><?php _e('Style 3 - Preset 2', 'adportfolio'); ?></option>



       <option class="style3-preset3" value="p3style3"><?php _e('Style 3 - Preset 3', 'adportfolio'); ?></option>



	   <option class="style3-preset4" value="p4style3"><?php _e('Style 3 - Preset 4', 'adportfolio'); ?></option>


	   <option class="style4-preset1" value="p1style4"><?php _e('Style 4 - Preset 1', 'adportfolio'); ?></option>


       <option class="style4-preset2" value="p2style4"><?php _e('Style 4 - Preset 2', 'adportfolio'); ?></option>


       <option class="style4-preset3" value="p3style4"><?php _e('Style 4 - Preset 3', 'adportfolio'); ?></option>
		
       <option class="style5-preset1" value="p1style5"><?php _e('Style 5 - Preset 1', 'adportfolio'); ?></option>
	   <option class="style5-preset2" value="p2style5"><?php _e('Style 5 - Preset 2', 'adportfolio'); ?></option>
	   <option class="style5-preset3" value="p3style5"><?php _e('Style 5 - Preset 3', 'adportfolio'); ?></option>
       <option class="style5-preset4" value="p4style5"><?php _e('Style 5 - Preset 4', 'adportfolio'); ?></option>
       <option class="style5-preset5" value="p5style5"><?php _e('Style 5 - Preset 5', 'adportfolio'); ?></option>
       <option class="style5-preset6" value="p6style5"><?php _e('Style 5 - Preset 6', 'adportfolio'); ?></option>
       <option class="style5-preset7" value="p7style5"><?php _e('Style 5 - Preset 7', 'adportfolio'); ?></option>
       <option class="style5-preset8" value="p8style5"><?php _e('Style 5 - Preset 8', 'adportfolio'); ?></option>
       <option class="style5-preset9" value="p9style5"><?php _e('Style 5 - Preset 9', 'adportfolio'); ?></option>
       <option class="style5-preset10" value="p10style5"><?php _e('Style 5 - Preset 10', 'adportfolio'); ?></option>
     </select>      
       <p class="position"><?php _e('Select Category (Multiple category is allowed)', 'adportfolio'); ?></p>
       
       <select id="adportfolio-category" multiple="multiple">
       <option value="all"><?php _e('All','adportfolio'); ?></option>
	   <?php 
  			$categories = get_categories(); 
  			foreach ($categories as $category) {
			$option = '<option value="'.$category->slug.'">';
			$option .= $category->cat_name;
			$option .= ' ('.$category->category_count.')';
			$option .= '</option>';
			echo $option;
  			}
 		?>
       </select>




		<p class="position"><?php _e('Number Post Load (Leave empty for all post): ', 'adportfolio'); ?></p>

   		<input type="text" class="adportfolio-number" name="adportfolio-number" id="adportfolio-number" value="">

	   <br />

		<div class="option-carousel" style="display:none">

		<p class="position"><?php _e('Post Visible: ', 'adportfolio'); ?></p>

   		<input type="text" class="adportfolio-postvisible" name="adportfolio-postvisible" id="adportfolio-postvisible" value="">
       
       <br />
       
 		<p class="position"><?php _e('Carousel Autoplay - Insert timeout (0 for no autoplay): ', 'adportfolio'); ?></p>

   		<input type="text" class="adportfolio-autoplay" name="adportfolio-autoplay" id="adportfolio-autoplay" value="">

 		<p class="position"><?php _e('Carousel Carousel Navigation Active: ', 'adportfolio'); ?></p>

         <select id="adportfolio-carousel-navigation-active" name="adportfolio-carousel-navigation-active" class="">
           <option class="yes" value="yes"><?php _e('Yes', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select> 

 		<p class="position"><?php _e('Carousel Carousel Navigation Display Position: ', 'adportfolio'); ?></p>

         <select id="adportfolio-carousel-navigation-display" name="adportfolio-carousel-navigation-display" class="">
           <option class="top" value="top"><?php _e('Top', 'adportfolio'); ?></option>
           <option class="bottom" value="bottom"><?php _e('Bottom', 'adportfolio'); ?></option>
         </select>   
       
 		<p class="position"><?php _e('Carousel Carousel Navigation Position: ', 'adportfolio'); ?></p>

         <select id="adportfolio-carousel-navigation-position" name="adportfolio-carousel-navigation-position" class="">
           <option class="left" value="left"><?php _e('Left', 'adportfolio'); ?></option>
           <option class="right" value="right"><?php _e('Right', 'adportfolio'); ?></option>
           <option class="center" value="center"><?php _e('Center', 'adportfolio'); ?></option>
         </select>      	
       
        </div>
       
        <div class="option-portfolio" style="display:none;"> 

         <p class="position"><?php _e('Link Position: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-link-position" name="adportfolio-portfolio-custom-link-position" class="">
           <option class="overlay" value="overlay"><?php _e('Overlay (Default)', 'adportfolio'); ?></option>
           <option class="image" value="image"><?php _e('Image', 'adportfolio'); ?></option>          
         </select>          
         
         <p class="position"><?php _e('Link Format: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-link-format" name="adportfolio-portfolio-custom-link-format" class="">
           <option class="yes" value="yes"><?php _e('Yes', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select> 
       
         <p class="position"><?php _e('Link Post/URL: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-link-post-url" name="adportfolio-portfolio-custom-link-post-url" class="">
           <option class="post" value="post"><?php _e('Post', 'adportfolio'); ?></option>
           <option class="url" value="url"><?php _e('URL', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select>   
         
         <p class="position"><?php _e('Link Target: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-link-target" name="adportfolio-portfolio-custom-link-target" class="">
           <option class="_blank" value="_blank"><?php _e('Blank', 'adportfolio'); ?></option>
           <option class="self" value="self"><?php _e('Self', 'adportfolio'); ?></option>
         </select>         

         <p class="position"><?php _e('Title: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-title" name="adportfolio-portfolio-custom-title" class="">
           <option class="yes" value="yes"><?php _e('Yes', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select>   

         <p class="position"><?php _e('Date: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-date" name="adportfolio-portfolio-custom-date" class="">
           <option class="yes" value="yes"><?php _e('Yes', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select> 

         <p class="position"><?php _e('Text: ', 'adportfolio'); ?></p>

         <select id="adportfolio-portfolio-custom-text" name="adportfolio-portfolio-custom-text" class="">
           <option class="yes" value="yes"><?php _e('Yes', 'adportfolio'); ?></option>
           <option class="no" value="no"><?php _e('No', 'adportfolio'); ?></option>
         </select>        

 		<p class="position"><?php _e('Number Text Excerpt: ', 'adportfolio'); ?></p>

   		<input type="text" class="adportfolio-portfolio-custom-excerpt" name="adportfolio-portfolio-custom-excerpt" id="adportfolio-portfolio-custom-excerpt" value="">
       
        </div>
        <br />      
       <input name="adportfolio-generator-insert" type="submit" class="button button-primary button-large" id="adportfolio-generator-insert" value="Insert Shortcodes">
       
       </div>

   </div>
   
	<?php

}

add_action( 'admin_footer', 'adportfolio_generator' );