<?php
/*
File: inc/install.php
Description: Install functions
Plugin: AD Portfolio
Author: Ad-theme.com
*/


//***************************************************************************
// Options Install/Unistall
//***************************************************************************

register_activation_hook(__FILE__,'adportfolio_install_options');
register_deactivation_hook(__FILE__, 'adportfolio_uninstall_options');


// Install Options Function
function adportfolio_install_options() {
	
	// Force to uninstall past options
    adportfolio_uninstall_options();
	
	// Add the options
	add_option('adportfolio_custom_css','');
	
	// Update the revrite rules on activation
	flush_rewrite_rules();
	
}

// Uninstall Options Function
function adportfolio_uninstall_options() { 

	// Remove Options
	delete_option('adportfolio_custom_css');
	
	// Update the revrite rules on deactivation
	flush_rewrite_rules();
	
}



//***************************************************************************
// Plugin INIT
//***************************************************************************


// LANGUAGE
add_action('init', 'adportfolio_language');

function adportfolio_language() {
	
	load_plugin_textdomain('adportfolio', false, adportfolio_DIR . '/languages/'); 
	
}

// ASSETS
require_once(adportfolio_DIR.'inc/assets.php');

// MENUS & PAGES
require_once(adportfolio_DIR.'inc/menus.php');

// ADMIN PAGES
require_once(adportfolio_DIR.'inc/pages.php');

// METABOXES
require_once(adportfolio_DIR.'inc/metaboxes.php');

// CUSTOM PORTFOLIO
require_once(adportfolio_DIR.'inc/portfolio.custom.php');

// SHORTCODES
require_once(adportfolio_DIR.'inc/shortcodes.php');
require_once(adportfolio_DIR.'inc/shortcodes.carousel.style1.php');
require_once(adportfolio_DIR.'inc/shortcodes.carousel.style2.php');
require_once(adportfolio_DIR.'inc/shortcodes.carousel.style3.php');
require_once(adportfolio_DIR.'inc/shortcodes.carousel.style4.php');
require_once(adportfolio_DIR.'inc/shortcodes.carousel.style5.php');