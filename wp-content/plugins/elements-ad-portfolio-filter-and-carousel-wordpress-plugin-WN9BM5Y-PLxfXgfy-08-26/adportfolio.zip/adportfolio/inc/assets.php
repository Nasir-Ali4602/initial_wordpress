<?php
/*
File: inc/assets.php
Description: Assets inclusion
Plugin: AD Portfolio
Author: Ad-theme.com
*/



//********************************************************************************//
// CSS
//********************************************************************************//


// Frontend
add_action( 'wp_enqueue_scripts', 'adportfolio_frontend_styles' );

function adportfolio_frontend_styles() {
	
	// Main
	wp_register_style( 'adportfolio-main-style',  adportfolio_URL . 'assets/css/frontend.css' );
    wp_enqueue_style( 'adportfolio-main-style' );

	// Style1 - Presets 1
	wp_register_style( 'style-preset1',  adportfolio_URL . 'assets/css/style-preset1.css' );
    wp_enqueue_style( 'style-preset1' );
	// Style1 - Presets 2
	wp_register_style( 'style-preset2',  adportfolio_URL . 'assets/css/style-preset2.css' );
    wp_enqueue_style( 'style-preset2' );
	// Style1 - Presets 3
	wp_register_style( 'style-preset3',  adportfolio_URL . 'assets/css/style-preset3.css' );
    wp_enqueue_style( 'style-preset3' );
	// Style2 - Presets 1
	wp_register_style( 'style2-preset1',  adportfolio_URL . 'assets/css/style2-preset1.css' );
    wp_enqueue_style( 'style2-preset1' );
	// Style2 - Presets 2
	wp_register_style( 'style2-preset2',  adportfolio_URL . 'assets/css/style2-preset2.css' );
    wp_enqueue_style( 'style2-preset2' );
	// Style2 - Presets 3
	wp_register_style( 'style2-preset3',  adportfolio_URL . 'assets/css/style2-preset3.css' );
    wp_enqueue_style( 'style2-preset3' );
	// Style3 - Presets 1
	wp_register_style( 'style3-preset1',  adportfolio_URL . 'assets/css/style3-preset1.css' );
    wp_enqueue_style( 'style3-preset1' );
	// Style3 - Presets 2
	wp_register_style( 'style3-preset2',  adportfolio_URL . 'assets/css/style3-preset2.css' );
    wp_enqueue_style( 'style3-preset2' );
	// Style3 - Presets 3
	wp_register_style( 'style3-preset3',  adportfolio_URL . 'assets/css/style3-preset3.css' );
    wp_enqueue_style( 'style3-preset3' );
	// Style3 - Presets 4
	wp_register_style( 'style3-preset4',  adportfolio_URL . 'assets/css/style3-preset4.css' );
    wp_enqueue_style( 'style3-preset4' );
	// Style4 - Presets 1
	wp_register_style( 'style4-preset1',  adportfolio_URL . 'assets/css/style4-preset1.css' );
    wp_enqueue_style( 'style4-preset1' );
	// Style4 - Presets 2
	wp_register_style( 'style4-preset2',  adportfolio_URL . 'assets/css/style4-preset2.css' );
    wp_enqueue_style( 'style4-preset2' );
	// Style4 - Presets 3
	wp_register_style( 'style4-preset3',  adportfolio_URL . 'assets/css/style4-preset3.css' );
    wp_enqueue_style( 'style4-preset3' );
	// Style5 - Presets 1
	wp_register_style( 'style5-preset1',  adportfolio_URL . 'assets/css/style5-preset1.css' );
    wp_enqueue_style( 'style5-preset1' );
	// Style5 - Presets 2
	wp_register_style( 'style5-preset2',  adportfolio_URL . 'assets/css/style5-preset2.css' );
    wp_enqueue_style( 'style5-preset2' );	
	// Style5 - Presets 3
	wp_register_style( 'style5-preset3',  adportfolio_URL . 'assets/css/style5-preset3.css' );
    wp_enqueue_style( 'style5-preset3' );
	// Style5 - Presets 4
	wp_register_style( 'style5-preset4',  adportfolio_URL . 'assets/css/style5-preset4.css' );
    wp_enqueue_style( 'style5-preset4' );
	// Style5 - Presets 5
	wp_register_style( 'style5-preset5',  adportfolio_URL . 'assets/css/style5-preset5.css' );
    wp_enqueue_style( 'style5-preset5' );
	// Style5 - Presets 6
	wp_register_style( 'style5-preset6',  adportfolio_URL . 'assets/css/style5-preset6.css' );
    wp_enqueue_style( 'style5-preset6' );
	// Style5 - Presets 7
	wp_register_style( 'style5-preset7',  adportfolio_URL . 'assets/css/style5-preset7.css' );
    wp_enqueue_style( 'style5-preset7' );			
	// Style5 - Presets 8
	wp_register_style( 'style5-preset8',  adportfolio_URL . 'assets/css/style5-preset8.css' );
    wp_enqueue_style( 'style5-preset8' );
	// Style5 - Presets 9
	wp_register_style( 'style5-preset9',  adportfolio_URL . 'assets/css/style5-preset9.css' );
    wp_enqueue_style( 'style5-preset9' );
	// Style5 - Presets 10
	wp_register_style( 'style5-preset10',  adportfolio_URL . 'assets/css/style5-preset10.css' );
    wp_enqueue_style( 'style5-preset10' );
																	
	// Fonts
	wp_register_style( 'adportfolio-fonts-style',  adportfolio_URL . 'assets/css/fonts.css' );
    wp_enqueue_style( 'adportfolio-fonts-style' );
	
	// Inline
	wp_add_inline_style( 'adportfolio-main-style', get_option('adportfolio_custom_css') ); 
	
}


// Backend
add_action( 'admin_enqueue_scripts', 'adportfolio_backend_styles' );

function adportfolio_backend_styles() {
	
	// Main
	wp_register_style( 'adportfolio-backend-style',  adportfolio_URL . 'assets/css/backend.css' );
    wp_enqueue_style( 'adportfolio-backend-style' );
	
}



//********************************************************************************//
// JS
//********************************************************************************//


// Frontend
add_action('wp_enqueue_scripts', 'adportfolio_frontend_scripts');

function adportfolio_frontend_scripts() {
	
	// Load WP jQuery if not included
	wp_enqueue_script('jquery');
	
	// Load main js script
	wp_enqueue_script('adportfolio-frontend-script', adportfolio_URL . 'assets/js/frontend.js', array('jquery'), '', true);
	
	// QUICKSAND EFFECT

	wp_enqueue_script('jquery.easing.1.3.js', adportfolio_URL . 'assets/js/jquery.easing.1.3.js', array('jquery'), '', true);
	wp_enqueue_script('jquery.quicksand.js', adportfolio_URL . 'assets/js/jquery.quicksand.js', array('jquery'), '', true);
	wp_enqueue_script('jquery.cycle2.min.js', adportfolio_URL . 'assets/js/jquery.cycle2.min.js', array('jquery'), '', true);
	wp_enqueue_script('jquery.cycle2.carousel.min.js', adportfolio_URL . 'assets/js/jquery.cycle2.carousel.min.js', array('jquery'), '', true);
	wp_enqueue_script('main.js', adportfolio_URL . 'assets/js/main.js', array('jquery'), '', true);	
	
	/* Codex
	wp_register_script( $handle, $src, $deps, $ver, $in_footer );
	*/
	
}


// Backend
add_action('admin_enqueue_scripts', 'adportfolio_backend_scripts');

function adportfolio_backend_scripts() {
	
	// Load WP jQuery if not included
	wp_enqueue_script('jquery');
	
	// Load main js script
	wp_enqueue_script('adportfolio-backend-script', adportfolio_URL . 'assets/js/backend.js', array('jquery'), '', true);
	
	/* Codex
	wp_register_script( $handle, $src, $deps, $ver, $in_footer );
	*/
	
}

if (!function_exists('adtheme_theme_setup')):

    function adtheme_theme_setup() {
		add_image_size( 'adportfolio', 260, 260, true );
		add_image_size( 'adportfolio-style4', 280, 280, true );
		add_image_size( 'adportfolio-style5', 300, 200, true );
	}
	
endif;

add_action('after_setup_theme', 'adtheme_theme_setup');