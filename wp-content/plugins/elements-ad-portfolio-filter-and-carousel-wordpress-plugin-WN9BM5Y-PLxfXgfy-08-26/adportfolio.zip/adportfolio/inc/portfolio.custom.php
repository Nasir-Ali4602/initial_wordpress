<?php
/*
File: inc/portfolio.custom.php
Description: Portfolio Custom
Plugin: AD Portfolio
Author: Ad-theme.com
*/

/****************************************** STYLE 1 - PRESET 1 ****************************************/

function adportfolio_function ($style,$category,$number,$custom_size,$link_position,$link_format,$link_post_url,$link_target,$title,$date,$text,$excerpt) {
	global $post;
	$custom_size = 'adportfolio';
	if(empty($excerpt)) { $excerpt = '100'; }
	if($style == 'style4-preset1' || $style == 'style4-preset2' || $style == 'style4-preset3') { $custom_size = 'adportfolio-style4'; }	
	
?>
<div class="adportfolio <?php echo $style; ?>">
  <ul id="filterOptions">
    <li class="active"><a href="#" class="all">All</a></li>
	<?php
	if ($category == 'all') {
    $categories = get_categories();
	  foreach ( $categories as $category ) {
      echo '<li><a href="#" class="' . $category->slug . '">' . $category->name . '</a></li>';
    }
	$category = '';
	} else {
		$category_single = explode( ',', $category );
		foreach ( $category_single as $category_name ) {
      		echo '<li><a href="#" class="' . $category_name . '">'; 
			
			$idObj = get_category_by_slug($category_name); 
  			$name = $idObj->term_id;
			echo get_cat_name($name);
			//$category_name . 
			echo '</a></li>';
    	}
		
	}
    ?>
</ul>  
<?php
if($number == '') { $number = '-1'; }

$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
$i=1;
?>
<ul class="ourHolder">
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<li class="item" data-id="id-<?php echo $i;?>" data-type="<?php $category = get_the_category(); 
echo $category[0]->slug; ?>">
			<div class="container-item">
				<div class="item">
                
                <?php
                
                		// LINK
									
						if($link_post_url != 'no') { // IF POST URL
							if($link_post_url == 'post') {
								$link = get_permalink();
							}
						if($link_post_url == 'url') {
								$link = get_post_meta( $post->ID, '_portfolio_url_value', true );
							}	
						} // END IF POST URL
						
				?>		
                <?php if($link_position == "image") {  // IF LINK IMAGE
               		

					
					?>
                    
                        <a href="<?php echo $link; ?>" target="<?php echo $link_target; ?>">                                        
							<?php if(has_post_thumbnail()){ ?>
                                <?php the_post_thumbnail( $custom_size ); ?>
                            <?php } else { ?>               
                                <img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
                        <?php } ?>
                 		</a>
                        
				 <?php } else { // ELSE LINK IMAGE ?> 
                 
                                                               
							<?php if(has_post_thumbnail()){ ?>
                                <?php the_post_thumbnail( $custom_size ); ?>
                            <?php } else { ?>               
                                <img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
                        	<?php } ?>                                              
                 
                 
                 
					<div class="item-overlay">
						 
                        <?php
						
						$format = get_post_format();
						if ( false === $format )
						$format = 'standard';
						
						?>
						                                             
                        <?php 
						
						// FORMAT
						
						if($link_format == 'yes') { ?>
                        
                            <a href="<?php echo site_url() . '/?post_format='.$format.''; ?>" class="item-button						                     
                            
                            <?php
                                                  
                            echo $format;
                            
                            ?>                        
                            "><i class="play"></i></a>
                        
                        <?php } ?>
                        
                        <?php if(
								$style == 'style3-preset1' || 
								$style == 'style3-preset2' || 
								$style == 'style3-preset3' || 
								$style == 'style3-preset4' || 
								$style == 'style4-preset1' ||
								$style == 'style4-preset2' ||
								$style == 'style4-preset3')  
								{ 
								
								// LINK
								
								if($link_post_url != 'no') {
									if($link_post_url == 'post') {
										$link = get_permalink();
									}
									if($link_post_url == 'url') {
										$link = get_post_meta( $post->ID, '_portfolio_url_value', true );
									}
									
						?>
                        
                        			<a href="<?php echo $link; ?>" class="item-button plus" target="<?php echo $link_target; ?>"><i class="plus"></i></a>
                        
                        		<?php }
						
								} ?>
                        
					</div>
					<div class="item-content">
						<div class="item-top-content">
							<div class="item-top-content-inner">
								<div class="item-product">
									<div class="item-top-title">
						
                        			<?php
                        				
									// TITLE
						
									if($title == 'yes') { ?>                                        
                                        
                                        <a href="<?php echo $link; ?>" title="<?php the_title();?>" target="<?php echo $link_target; ?>">
        								<h2><?php the_title();?></h2>
        								</a>
                                    
                                    <?php } ?>    

                        			<?php
                        				
									// DATE
						
									if($date == 'yes') { ?> 
                                        
                                        <h6><?php echo get_the_date('m/d/Y'); ?></h6>
                                    
                                    <?php } ?>     
                                        
									</div>
								</div>
								<div class="item-product-price">
								</div>
							</div>	
						</div>
						<div class="item-add-content">
							<div class="item-add-content-inner">
								<div class="section">
                                
                                <?php
                                
								// LINK
								
                                if($text == 'yes') { ?>
                                
                                <p class="text"><?php echo substr(get_the_excerpt(), 0, $excerpt); ?></p>
                                                                
                                <?php } ?>
                                
                                <?php
                                
								
								if(
								$style == 'style1-preset1' || 
								$style == 'style1-preset2' || 
								$style == 'style1-preset3' ||  
								$style == 'style2-preset1' ||
								$style == 'style2-preset2' ||
								$style == 'style2-preset3')  
								{ 
								
								// LINK
								
								if($link_post_url != 'no') {
									if($link_post_url == 'post') {
										$link = get_permalink();
									}
									if($link_post_url == 'url') {
										$link = get_post_meta( $post->ID, '_portfolio_url_value', true );
									} 
								
								?>
                                
									<a href="<?php echo $link; ?>" class="btn buy expand"><?php _e('Read more','adportfolio'); ?></a>
								
                                <?php } 
								
								} ?>
                                
                                </div>
							</div>
						</div>
					</div>
                    <?php } // END IF LINK IMAGE ?>
				</div>
			</div>
</li>
<script>
jQuery(function($){

	$(window).load(function(){

		$(".share-btn.loop<?php echo $i;?>").mouseenter(function() {
			setTimeout(function() {
			$(".item-menu.loop<?php echo $i;?>").addClass("visible")
			}, 500);
		});
		$(".share-btn.loop<?php echo $i;?>").mouseleave(function() {
			setTimeout(function() {
			$(".item-menu.loop<?php echo $i;?>").removeClass("visible")
			}, 500);
		});
	});

});
</script>
<?php 
	$i++;
	endwhile; 
	}

?>
</ul>
</div>
<?php }

function adportfolio ( $attr ) {
		ob_start();
		$style = $attr['style'];
		$category = $attr['category'];
		$number = $attr['number'];
		$custom_size = $attr['custom_size'];
		$link_position = $attr['link_position'];
		$link_format = $attr['link_format'];
		$link_post_url = $attr['link_post_url'];
		$link_target = $attr['link_target'];
		$title = $attr['title'];
		$date = $attr['date'];
		$text = $attr['text'];
		$excerpt = $attr['excerpt'];
        $return = adportfolio_function($style,$category,$number,$custom_size,$link_position,$link_format,$link_post_url,$link_target,$title,$date,$text,$excerpt);  
    	$return = ob_get_clean();
		return $return;
	}  
add_shortcode("adportfolio", "adportfolio");





/****************************************** STYLE 5 ****************************************/

function adportfolio_function_style5 ($style,$category,$number,$custom_size,$link_position,$link_format,$link_post_url,$link_target,$title,$date,$text,$excerpt) {
	global $post;
	$custom_size = 'adportfolio-style5';
	if(empty($excerpt)) { $excerpt = '100'; }
	if($style == 'style5-preset1') { $style_num = 'first'; }
	if($style == 'style5-preset2') { $style_num = 'second'; }
	if($style == 'style5-preset3') { $style_num = 'third'; }
	if($style == 'style5-preset4') { $style_num = 'fourth'; }
	if($style == 'style5-preset5') { $style_num = 'fifth'; }
	if($style == 'style5-preset6') { $style_num = 'sixth'; }
	if($style == 'style5-preset7') { $style_num = 'seventh'; }
	if($style == 'style5-preset8') { $style_num = 'eighth'; }
	if($style == 'style5-preset9') { $style_num = 'ninth'; }
	if($style == 'style5-preset10') { $style_num = 'tenth'; }	
	
?>
<div class="adportfolio <?php echo $style; ?>">
  <ul id="filterOptions">
    <li class="active"><a href="#" class="all">All</a></li>
	<?php
	if ($category == 'all') {
    $categories = get_categories();
	  foreach ( $categories as $category ) {
      echo '<li><a href="#" class="' . $category->slug . '">' . $category->name . '</a></li>';
    }
	$category = '';
	} else {
		$category_single = explode( ',', $category );
		foreach ( $category_single as $category_name ) {
      		echo '<li><a href="#" class="' . $category_name . '">'; 
			
			$idObj = get_category_by_slug($category_name); 
  			$name = $idObj->term_id;
			echo get_cat_name($name);
			//$category_name . 
			echo '</a></li>';
    	}
		
	}
    ?>
</ul>  
<?php
if($number == '') { $number = '-1'; }

$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
$i=1;
?>
<ul class="ourHolder">
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
<li class="item" data-id="id-<?php echo $i;?>" data-type="<?php $category = get_the_category(); 
echo $category[0]->slug; ?>">
			<div class="main">
                <div class="view view-<?php echo $style_num; ?>">
                
                <?php
                
                		// LINK
									
						if($link_post_url != 'no') { // IF POST URL
							if($link_post_url == 'post') {
								$link = get_permalink();
							}
						if($link_post_url == 'url') {
								$link = get_post_meta( $post->ID, '_portfolio_url_value', true );
							}	
						} // END IF POST URL
						
				?>		
                <?php if($link_position == "image") {  // IF LINK IMAGE
               		

					
					?>
                    
                        <a href="<?php echo $link; ?>" target="<?php echo $link_target; ?>">                                        
							<?php if(has_post_thumbnail()){ ?>
                                <?php the_post_thumbnail( $custom_size ); ?>
                            <?php } else { ?>               
                                <img src="<?php echo adportfolio_URL; ?>/assets/img/no-img-300x200.png" alt="no img" >               
                        <?php } ?>
                 		</a>
                        
				 <?php } else { // ELSE LINK IMAGE ?> 
                 
                                                               
							<?php if(has_post_thumbnail()){ ?>
                                <?php the_post_thumbnail( $custom_size ); ?>
                            <?php } else { ?>               
                                <img src="<?php echo adportfolio_URL; ?>/assets/img/no-img-300x200.png" alt="no img" >               
                        	<?php } ?>                                              
                 
                 
                    <?php if($style == 'style5-preset2') { ?>
                        <div class="mask"></div>
                        <div class="content">
                    <?php } elseif ($style == 'style5-preset9') { ?>
                        <div class="mask mask-1"></div>
                    	<div class="mask mask-2"></div>
                    	<div class="content">
                    <?php } else { ?>
						<div class="mask">
					<?php } ?>
						
                        			<?php
                        				
									// TITLE
						
									if($title == 'yes') { ?>                                        
                                        
                                        <a href="<?php echo $link; ?>" title="<?php the_title();?>" target="<?php echo $link_target; ?>">
        								<h2><?php the_title();?></h2>
        								</a>
                                    
                                    <?php } ?>    

                        			<?php
                        				
									// DATE
						
									if($date == 'yes') { ?> 
                                        
                                        <p class="date"><?php echo get_the_date('m/d/Y'); ?></p>
                                    
                                    <?php } ?>     
                                        
                                
                                <?php
                                
								// LINK
								
                                if($text == 'yes') { ?>
                                
                                <p class="text"><?php echo substr(get_the_excerpt(), 0, $excerpt); ?></p>
                                                                
                                <?php } ?>
                                
                                <?php
								
								// LINK
								
								if($link_post_url != 'no') {
									if($link_post_url == 'post') {
										$link = get_permalink();
									}
									if($link_post_url == 'url') {
										$link = get_post_meta( $post->ID, '_portfolio_url_value', true );
									} 
								
								?>
                                
									<a href="<?php echo $link; ?>" class="info"><?php _e('Read more','adportfolio'); ?></a>
								
                                <?php } ?>
                                
                                </div>
                                                                
                    <?php } // END IF LINK IMAGE ?>
				</div>
			</div>
</li>
<?php 
	$i++;
	endwhile; 
	}

?>
</ul>
</div>
<?php }

function adportfolio_style5 ( $attr ) {
		ob_start();
		$style = $attr['style'];
		$category = $attr['category'];
		$number = $attr['number'];
		$custom_size = $attr['custom_size'];
		$link_position = $attr['link_position'];
		$link_format = $attr['link_format'];
		$link_post_url = $attr['link_post_url'];
		$link_target = $attr['link_target'];
		$title = $attr['title'];
		$date = $attr['date'];
		$text = $attr['text'];
		$excerpt = $attr['excerpt'];
        $return = adportfolio_function_style5 ($style,$category,$number,$custom_size,$link_position,$link_format,$link_post_url,$link_target,$title,$date,$text,$excerpt);  
    	$return = ob_get_clean();
		return $return;
	}  
add_shortcode("adportfolio_style5", "adportfolio_style5");