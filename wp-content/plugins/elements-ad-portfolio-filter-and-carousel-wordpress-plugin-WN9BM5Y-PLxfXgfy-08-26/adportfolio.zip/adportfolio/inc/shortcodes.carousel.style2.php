<?php
/*
File: inc/shortcodes.carousel.style2.php
Description: Plugin shortcodes
Plugin: AD Portfolio
Author: Ad-theme.com
*/

/****************************************** STYLE 2 - PRESET 1 ****************************************/

function adcarousel_style2_p1 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style2-preset1 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style2-preset1 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
				<div class="item">
                	<?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
					<div class="item-overlay">
						 
                        <?php
						
						$format = get_post_format();
						if ( false === $format )
						$format = 'standard';
						
						?>
						
						<a href="<?php echo site_url() . '/?post_format='.$format.''; ?>" class="item-button
						
                        <?php
						                      
						echo $format;
						
						?>                        
                        "><i class="play"></i></a>
					</div>
					<div class="item-content">
						<div class="item-top-content">
							<div class="item-top-content-inner">
								<div class="item-product">
									<div class="item-top-title">
										
                                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        								<h2><?php the_title();?></h2>
        								</a>
                                        <h6><?php echo get_the_date('m/d/Y'); ?></h6>
									</div>
								</div>
								<div class="item-product-price">
								</div>
							</div>	
						</div>
						<div class="item-add-content">
							<div class="item-add-content-inner">
								<div class="section">
                                <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
									<a href="<?php the_permalink(); ?>" class="btn buy expand"><?php _e('Read more','adportfolio'); ?></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style2-preset1 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p1style2 ( $attr ) {
		ob_start();
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style2_p1($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;
	}  
add_shortcode("adcarousel_p1style2", "adcarousel_p1style2");

/****************************************** STYLE 2 - PRESET 2 ****************************************/

function adcarousel_style2_p2 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style2-preset2 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style2-preset2 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
				<div class="item">
                	<?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
					<div class="item-overlay">
						 
                        <?php
						
						$format = get_post_format();
						if ( false === $format )
						$format = 'standard';
						
						?>
						
						<a href="<?php echo site_url() . '/?post_format='.$format.''; ?>" class="item-button
						
                        <?php
						                      
						echo $format;
						
						?>                        
                        "><i class="play"></i></a>
					</div>
					<div class="item-content">
						<div class="item-top-content">
							<div class="item-top-content-inner">
								<div class="item-product">
									<div class="item-top-title">
										
                                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        								<h2><?php the_title();?></h2>
        								</a>
                                        <h6><?php echo get_the_date('m/d/Y'); ?></h6>
									</div>
								</div>
								<div class="item-product-price">
								</div>
							</div>	
						</div>
						<div class="item-add-content">
							<div class="item-add-content-inner">
								<div class="section">
                                <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
									<a href="<?php the_permalink(); ?>" class="btn buy expand"><?php _e('Read more','adportfolio'); ?></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style2-preset2 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p2style2 ( $attr ) {
		ob_start();
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style2_p2($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;
	}  
add_shortcode("adcarousel_p2style2", "adcarousel_p2style2");

/****************************************** STYLE 2 - PRESET 3 ****************************************/

function adcarousel_style2_p3 ($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation) {
	global $post; 
	
	if($category == 'all') { $category = ''; }
	
	$loop = new WP_Query(array('post_type' => 'Post', 'posts_per_page' => $number, 'post_status' => 'publish', 'category_name' => $category ));
	
	if(empty($visible) || $visible == '0') { $visible = '3'; }
	
?>
<?php if($navigation_active == 'yes' && $navigation_display == 'top') { ?>
<div class="adportfolio style2-preset3 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<div class="clear"></div>
<div id="list_post" 
data-cycle-carousel-vertical="false" 
data-cycle-carousel-fluid="true" 
data-cycle-fx=carousel
data-cycle-carousel-visible="<?php echo $visible; ?>"
data-cycle-next="#next"
data-cycle-prev="#prev"
data-cycle-pause-on-hover="true"
data-cycle-timeout="<?php echo $autoplay; ?>"
class="adportfolio style2-preset3 carousel"
>
<?php if($loop) { ?>
<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="container-item slides">
				<div class="item">
                	<?php if(has_post_thumbnail()){ ?>
                        <?php the_post_thumbnail( 'adportfolio' ); ?>
               		<?php } else { ?>               
               			<img src="<?php echo adportfolio_URL; ?>/assets/img/no-img.png" alt="no img" >               
              		<?php } ?>
					<div class="item-overlay">
						 
                        <?php
						
						$format = get_post_format();
						if ( false === $format )
						$format = 'standard';
						
						?>
						
						<a href="<?php echo site_url() . '/?post_format='.$format.''; ?>" class="item-button
						
                        <?php
						                      
						echo $format;
						
						?>                        
                        "><i class="play"></i></a>
					</div>
					<div class="item-content">
						<div class="item-top-content">
							<div class="item-top-content-inner">
								<div class="item-product">
									<div class="item-top-title">
										
                                        <a href="<?php the_permalink(); ?>" title="<?php the_title();?>">
        								<h2><?php the_title();?></h2>
        								</a>
                                        <h6><?php echo get_the_date('m/d/Y'); ?></h6>
									</div>
								</div>
								<div class="item-product-price">
								</div>
							</div>	
						</div>
						<div class="item-add-content">
							<div class="item-add-content-inner">
								<div class="section">
                                <p class="text"><?php echo substr(get_the_excerpt(), 0, 100); ?></p>
									<a href="<?php the_permalink(); ?>" class="btn buy expand"><?php _e('Read more','adportfolio'); ?></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php
	endwhile; 
	}
?>
<script>
jQuery(document).ready(function($){
$('#list_post').cycle({ 
 slides: '> div'
 });  
}); 
</script>
</div>
<?php if($navigation_active == 'yes' && $navigation_display == 'bottom') { ?>
<div class="adportfolio style2-preset3 carousel carousel-navigation <?php echo $navigation_display; ?> <?php echo $position_navigation; ?>">
    <a href="#" id="prev"><img src="<?php echo adportfolio_URL; ?>/assets/img/prev.png" alt="prev"></a>
    <a href="#" id="next"><img src="<?php echo adportfolio_URL; ?>/assets/img/next.png" alt="next"></a>
</div>
<?php } ?>
<?php
} 
function adcarousel_p3style2 ( $attr ) {
		ob_start();
		$category = $attr['category'];
		$number = $attr['number'];
		$autoplay = $attr['autoplay'];
		$visible = $attr['visible'];
		$navigation_active = $attr['navigation_active'];
		$navigation_display = $attr['dnavigation'];
		$position_navigation = $attr['pnavigation'];		
        $return = adcarousel_style2_p3($category,$number,$autoplay,$visible,$navigation_active,$navigation_display,$position_navigation);  
        $return = ob_get_clean();
		return $return;
	}  
add_shortcode("adcarousel_p3style2", "adcarousel_p3style2");